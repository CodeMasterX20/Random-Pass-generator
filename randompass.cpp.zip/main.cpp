#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
    string nouns[] = {
    "apple","banana","cherry","dragon","eagle","flower","ghost","honey","ice","jungle",
    "lion","tiger","wolf","bear","fox","rabbit","owl","penguin","dolphin","shark",
    "king","queen","moon","night","orange","rose","sun","star","cloud","tree",
    "umbrella","violet","anchor","book","cat","dog","elephant","forest","garden","hat",
    "island","jewel","kite","lamp","mountain","nest","ocean","pencil","river","snake",
    "train","unicorn","vase","window","xylophone","yacht","zeppelin","art","ball","cloud",
    "desk","ear","fan","globe","house","igloo","jacket","key","leaf","mirror",
    "needle","owl","plate","quilt","ring","fish","gate","hat","ink","jar",
    "knife","milk","net","paper","quill","rope","stone","table","urn","village",
    "whale","violin","zebra","yak","bee","frog","camel","lioness","cheetah","otter",
    "parrot","swan","bat","koala","giraffe","moose","pony","rat","seal","turkey"
    };
    int numbers[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 0}; 
    char specialChars[34] = {
    '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/',
    ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~'
    };
    srand(time(0));
    
    int indexno = rand() % 100;
    int indexnu = rand() % 10;
    int indexs = rand() % 34;
    string pass;
    string password;
    
    cout << "Hello! Say Pass to generate a random password." << endl;
    getline(cin, password);
    
    if (password == "Pass") {
        cout << "Okay! lets go make some passwords!" << endl;
        cout << "..." << endl;
        pass += nouns[indexno];
        pass += to_string(numbers[indexnu]);
        pass += specialChars[indexs];
        cout << pass << endl;
    }

    return 0;
}